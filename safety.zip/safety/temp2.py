
from google.cloud import storage
client = storage.Client()

# Reference an existing bucket.
bucket = client.get_bucket('ring-30c80.appspot.com')

# Upload a local file to a new file to be created in your bucket.
zebraBlob = bucket.get_blob('image0.jpg')
zebraBlob.upload_from_filename(filename='/home/pi/safety/image0.jpg')

# Download a file from your bucket.
giraffeBlob = bucket.get_blob('image.jpg')
giraffeBlob.download_as_string()
