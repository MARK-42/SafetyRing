print('v')
