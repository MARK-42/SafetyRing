from picamera import PiCamera
from time import sleep
import pyrebase

config = {
  "apiKey": "AIzaSyCseTBfi4W4kIlrDtf_pKan2tyKK-wThZs",
  "authDomain": "ring-30c80.firebaseapp.com",
  "databaseURL": "https://ring-30c80.firebaseio.com",
  "storageBucket": "ring-30c80.appspot.com"

}

firebase = pyrebase.initialize_app(config)

storage = firebase.storage()

camera = PiCamera()

camera.start_preview()
for i in range(30):
    sleep(0.5)
    camera.capture('/home/pi/safety/image%s.jpg' % i)
    path_on_cloud = ('images/image%s.jpg' % i)
    path_local= ('/home/pi/safety/image%s.jpg' % i)

    storage.child(path_on_cloud).put(path_local)


camera.stop_preview()
