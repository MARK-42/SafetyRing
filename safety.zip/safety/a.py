print('a')
