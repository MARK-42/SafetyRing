from firebase import firebase
import time

firebase=firebase.FirebaseApplication('https://ring-30c80.firebaseio.com/',None)

result = firebase.put('hello','p','1')
result = firebase.put('hello','q','2')

