import os
import pyrebase
import time

config = {
  "apiKey": "AIzaSyCseTBfi4W4kIlrDtf_pKan2tyKK-wThZs",
  "authDomain": "ring-30c80.firebaseapp.com",
  "databaseURL": "https://ring-30c80.firebaseio.com",
  "storageBucket": "ring-30c80.appspot.com"

}

firebase = pyrebase.initialize_app(config)

storage = firebase.storage()


myCmd = 'arecord --duration=15 --device=hw:1,0 --format S16_LE --rate 44100 -V mono -c1 voice15.wav'
os.system(myCmd)

path_on_cloud = "audio/voice15.wav"
path_local= "/home/pi/safety/voice15.wav"

storage.child(path_on_cloud).put(path_local)



