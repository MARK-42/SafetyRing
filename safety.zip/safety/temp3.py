import firebase_admin
from firebase_admin import credentials
from firebase_admin import db

cred = credentials.Certificate('ring-30c80-firebase-adminsdk-mwv4q-fcfb783db4.json')
default = firebase_admin.initialize_app(cred,{
'databaseURL': "https://ring-30c80.firebaseio.com/"
})
print(default.name)

ref = db.reference('status')
ref.push({
"student":{
    'emp1':{"firstName":"John", "lastName":"Doe"}, 
    'emp2':{"firstName":"Anna", "lastName":"Smith"},
    'emp3':{"firstName":"Peter", "lastName":"Jones"}
}
})
