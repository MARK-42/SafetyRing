
import RPi.GPIO as GPIO # Import Raspberry Pi GPIO library
import os
def button_callback(channel):
    print("Button was pushed!")
    os.system('python3 a.py & python3 v.py')
GPIO.setwarnings(False) # Ignore warning for now
GPIO.setmode(GPIO.BOARD) # Use physical pin numbering
GPIO.setup(10, GPIO.IN, pull_up_down=GPIO.PUD_DOWN) # Set pin 10 to be an input$
GPIO.add_event_detect(10,GPIO.RISING,callback=button_callback) # Setup event on$
message = input("Press enter to quit\n\n") # Run until someone presses enter
GPIO.cleanup()




