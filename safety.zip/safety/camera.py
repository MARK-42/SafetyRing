import os

proxy = 'http://172.31.1.5:8080'

os.environ['http_proxy'] = proxy 
os.environ['HTTP_PROXY'] = proxy
os.environ['https_proxy'] = proxy
os.environ['HTTPS_PROXY'] = proxy

import urllib2
#import keyword
#dir(keyword)
#from urllib import urljoin
#import python_jwt
#import urllib.request
from urllib import urlencode
#x = urllib.request.urlopen('https://www.google.com/')
#print(x.read())
from firebase import firebase
from google.cloud import storage
import os
from picamera import PiCamera
from time import sleep
from urlparse import urlparse
camera = PiCamera()

camera.start_preview()
for i in range(5):
    sleep(5)
    camera.capture('/home/pi/safety/image%s.jpg' % i)
camera.stop_preview()

os.environ["GOOGLE_APPLICATION_CREDENTIALS"]="/home/pi/safety/ring-30c80-firebase-adminsdk-mwv4q-fcfb783db4.json"
firebase = firebase.FirebaseApplication('ring-30c80.firebaseio.com')
client = storage.Client()
bucket = client.get_bucket('ring-30c80.appspot.com')
imageBlob = bucket.blob("/")
imagePath = "/home/pi/safety/image2.jpg"
imageBlob = bucket.blob("Newimage1.jpg")
imageBlob.upload_from_filename(imagePath)


